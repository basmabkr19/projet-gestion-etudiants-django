# etudiants/models.py
from django.db import models

class Etudiant(models.Model):
    nom = models.CharField(max_length=100)
    prenom = models.CharField(max_length=100)
    email = models.EmailField(unique=True) # L'email doit être unique
    date_naissance = models.DateField()
    date_inscription = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        # On affiche le prénom et le nom quand on affiche un objet étudiant
        return f"{self.prenom} {self.nom}"