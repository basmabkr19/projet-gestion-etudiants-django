# etudiants/views.py

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Etudiant
from .forms import EtudiantForm

# --- VUE POUR LA LISTE ---
@login_required  # <-- LE CADENAS EST ICI
def liste_etudiants(request):
    # On récupère TOUS les étudiants de la base de données
    etudiants = Etudiant.objects.all()
    context = {'etudiants': etudiants}
    return render(request, 'etudiants/liste_etudiants.html', context)

# --- VUE POUR AJOUTER ---
@login_required  # <-- CADENAS ICI AUSSI
def ajouter_etudiant(request):
    if request.method == 'POST':
        form = EtudiantForm(request.POST)
        if form.is_valid():
            form.save() # On sauvegarde simplement, pas besoin de lier à un utilisateur
            return redirect('liste_etudiants')
    else:
        form = EtudiantForm()
    return render(request, 'etudiants/ajouter_etudiant.html', {'form': form})

# --- VUE POUR MODIFIER ---
@login_required  # <-- ET ICI
def modifier_etudiant(request, etudiant_id):
    etudiant = get_object_or_404(Etudiant, id=etudiant_id)
    if request.method == 'POST':
        form = EtudiantForm(request.POST, instance=etudiant)
        if form.is_valid():
            form.save()
            return redirect('liste_etudiants')
    else:
        form = EtudiantForm(instance=etudiant)
    return render(request, 'etudiants/modifier_etudiant.html', {'form': form})

# --- VUE POUR SUPPRIMER ---
@login_required  # <-- ET ENCORE ICI
def supprimer_etudiant(request, etudiant_id):
    etudiant = get_object_or_404(Etudiant, id=etudiant_id)
    if request.method == 'POST':
        etudiant.delete()
        return redirect('liste_etudiants')
    return render(request, 'etudiants/supprimer_etudiant.html', {'etudiant': etudiant})